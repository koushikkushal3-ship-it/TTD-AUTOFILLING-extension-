// Fills pilgrim details into TTD forms. Only fills fields: never submits,
// never clicks pay/confirm, never touches CAPTCHA/OTP inputs.
(() => {
  // Replace any earlier copy of this script. When the extension is reloaded or updated,
  // the old copy is orphaned (its chrome.runtime is gone) but its globals stay behind,
  // so a plain "already loaded" flag would stop the fresh copy from ever listening.
  const prev = window.__ttdSmartFill;
  if (prev) {
    if (prev.alive()) return;
    prev.dispose();
  }

  const MAP = window.TTD_FIELD_MAP;
  const FORBIDDEN = window.TTD_FORBIDDEN;
  const ALIASES = window.TTD_VALUE_ALIASES;
  const ATTRS = ['name', 'formcontrolname', 'id', 'placeholder', 'aria-label'];
  // Fields that often appear or get enabled only after their parent is chosen.
  const DEPENDENT = new Set(['idNumber', 'city']);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => (s || '').replace(/[*:]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // "idProofNumber" / "IDProofNo" / "pilgrim_name" -> "id proof number" / "id proof no" / "pilgrim name"
  const words = (s) => (s || '')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .trim().toLowerCase();

  const CONTROL_SEL = [
    'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])',
    'select', 'textarea', 'mat-select', 'ng-select', '[role=combobox]:not(input)',
  ].join(', ');
  const OPTION_SEL = 'mat-option, .mat-option, .mat-mdc-option, .ng-option, [role=option]';

  const LABELS = {
    fullName: 'Name', age: 'Age', gender: 'Gender', idProofType: 'ID type', idNumber: 'ID number',
    mobile: 'Mobile', email: 'Email', city: 'City', state: 'State', pincode: 'PIN code',
  };

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  }

  const attrValues = (el) => ATTRS.map((a) => el.getAttribute(a)).filter(Boolean);
  const attrText = (el) => attrValues(el).join(' ');

  function isForbidden(el) {
    return el.type === 'password' || FORBIDDEN.test(attrText(el)) || FORBIDDEN.test(labelText(el));
  }

  // Visible label text for a control: <label for>, wrapping label, form-field label, or nearby text.
  function labelText(el) {
    const parts = [];
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) parts.push(l.textContent);
    }
    const wrap = el.closest('label');
    if (wrap) parts.push(wrap.textContent);
    const ff = el.closest('mat-form-field, .mat-mdc-form-field, .form-group, .form-field');
    if (ff) {
      const l = ff.querySelector('mat-label, label, .mat-form-field-label, .mdc-floating-label');
      if (l) parts.push(l.textContent);
    }
    if (!parts.length) {
      let sib = el.previousElementSibling;
      for (let i = 0; sib && i < 3; i++, sib = sib.previousElementSibling) {
        const t = sib.textContent.trim();
        if (t && t.length < 50) { parts.push(t); break; }
      }
      const psib = !parts.length && el.parentElement && el.parentElement.previousElementSibling;
      if (psib && psib.textContent.trim().length < 50) parts.push(psib.textContent);
    }
    return norm(parts.join(' '));
  }

  function isExcluded(rule, el, label) {
    if (!rule.exclude) return false;
    return attrValues(el).some((v) => rule.exclude.test(words(v))) || rule.exclude.test(label);
  }

  // All visible controls for a field, in document order (pilgrim 1, pilgrim 2, ...).
  function findControls(key) {
    const rule = MAP[key];
    for (const sel of rule.selectors || []) {
      const found = [...document.querySelectorAll(sel)].filter(isVisible);
      if (found.length) return found;
    }
    const all = [...document.querySelectorAll(CONTROL_SEL)].filter((el) => isVisible(el) && !isForbidden(el));
    // Each attribute is tested on its own, so anchors like ^ and $ mean what they say.
    const byAttr = all.filter((el) => attrValues(el).some((v) => rule.attr.test(words(v))) && !isExcluded(rule, el, labelText(el)));
    if (byAttr.length) return byAttr;
    return all.filter((el) => {
      const lt = labelText(el);
      return lt && rule.label.test(lt) && !isExcluded(rule, el, lt);
    });
  }

  // Set value so Angular/React form controls register the change.
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  function candidates(key, value) {
    const v = norm(value);
    const groups = ALIASES[key];
    if (groups) {
      for (const list of Object.values(groups)) if (list.includes(v)) return list;
    }
    return [v];
  }

  // Index of the option text best matching `value`: exact, then prefix word, then whole word,
  // then loose substring. The loose step is skipped for gender because "female" contains "male".
  function matchOption(texts, key, value) {
    const cands = candidates(key, value);
    const normed = texts.map(norm);
    const tests = [
      (t, c) => t === c,
      (t, c) => c.length > 1 && new RegExp('^' + esc(c) + '\\b').test(t),
      (t, c) => c.length > 1 && new RegExp('\\b' + esc(c) + '\\b').test(t),
      (t, c) => key !== 'gender' && c.length > 2 && t.includes(c),
    ];
    for (const test of tests) {
      const i = normed.findIndex((t) => cands.some((c) => test(t, c)));
      if (i >= 0) return i;
    }
    return -1;
  }

  async function waitFor(fn, timeout = 1500, step = 50) {
    const end = Date.now() + timeout;
    for (;;) {
      const r = fn();
      if (r || Date.now() > end) return r || null;
      await sleep(step);
    }
  }

  async function fillSelect(el, key, value) {
    // Options are often loaded only after a parent field changes (e.g. cities after state).
    await waitFor(() => el.options.length > 1, 1500);
    const opts = [...el.options];
    let i = matchOption(opts.map((o) => o.textContent), key, value);
    if (i < 0) i = matchOption(opts.map((o) => o.value), key, value);
    if (i < 0) return false;
    el.value = opts[i].value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function closeOverlay() {
    const target = document.activeElement || document.body;
    target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    const backdrop = document.querySelector('.cdk-overlay-backdrop');
    if (backdrop) backdrop.click();
  }

  function visibleOptions() {
    const list = [...document.querySelectorAll(OPTION_SEL)].filter(isVisible);
    return list.length ? list : null;
  }

  // Angular Material mat-select / ng-select / ARIA combobox: open it, click the matching option.
  async function fillCustomDropdown(el, key, value) {
    const trigger = el.querySelector('.mat-select-trigger, .mat-mdc-select-trigger, .ng-select-container') || el;
    trigger.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    trigger.click();
    const opts = await waitFor(visibleOptions);
    if (!opts) return false;
    const i = matchOption(opts.map((o) => o.textContent), key, value);
    if (i < 0) { closeOverlay(); return false; }
    opts[i].click();
    await waitFor(() => !isVisible(opts[i]), 800);
    return true;
  }

  // Autocomplete text inputs: type the value, then pick the suggestion if one appears.
  async function fillAutocomplete(el, key, value) {
    el.focus();
    setNativeValue(el, value);
    const opts = await waitFor(visibleOptions, 800);
    if (opts) {
      const i = matchOption(opts.map((o) => o.textContent), key, value);
      if (i >= 0) opts[i].click(); else closeOverlay();
    }
    return true;
  }

  // Radio groups (common for gender): the Nth group belongs to pilgrim N.
  function radioGroups(key) {
    const rule = MAP[key];
    const groups = new Map();
    document.querySelectorAll('input[type=radio]').forEach((input) => {
      const host = input.closest('mat-radio-button') || input;
      if (!isVisible(host) && !isVisible(input)) return;
      const groupEl = input.closest('mat-radio-group, [role=radiogroup], fieldset');
      const attrs = [...attrValues(input), ...(groupEl ? attrValues(groupEl) : [])].map(words);
      const label = [groupEl ? labelText(groupEl) : '', labelText(input)].join(' ');
      const optionText = norm(host.textContent || input.value);
      if (!attrs.some((a) => rule.attr.test(a)) && !rule.label.test(label) && !/^(male|female)$/.test(optionText)) return;
      const gkey = input.name || groupEl || 'default';
      if (!groups.has(gkey)) groups.set(gkey, []);
      groups.get(gkey).push({ input, host });
    });
    return [...groups.values()];
  }

  function fillRadio(group, key, value) {
    const texts = group.map(({ input, host }) => {
      const lbl = input.id && document.querySelector(`label[for="${CSS.escape(input.id)}"]`);
      return (lbl && lbl.textContent) || host.textContent || input.value;
    });
    const i = matchOption(texts, key, value);
    if (i < 0) return null;
    group[i].input.click();
    return group[i].host;
  }

  function highlight(el) {
    const box = el.closest('mat-form-field, .mat-mdc-form-field') || el;
    box.style.outline = '2px solid #663399';
    box.style.outlineOffset = '2px';
    setTimeout(() => { box.style.outline = ''; box.style.outlineOffset = ''; }, 6000);
  }

  // Result card in a shadow root so the site's CSS can't restyle it.
  function toast({ kind, title, detail, missed = [] }) {
    const old = document.getElementById('ttd-smart-fill-toast');
    if (old) old.remove();
    const host = document.createElement('div');
    host.id = 'ttd-smart-fill-toast';
    Object.assign(host.style, { position: 'fixed', bottom: '20px', right: '20px', zIndex: '2147483647' });
    const root = host.attachShadow({ mode: 'open' });
    const colors = { ok: '#663399', warn: '#c48a00', err: '#a10007' };
    root.innerHTML = `
      <style>
        .card { width: 340px; background: #fff; color: #233443; border-radius: 20px; overflow: hidden;
          font: 13.5px/1.45 "Open Sans", "Segoe UI", system-ui, sans-serif; box-shadow: 0 8px 28px rgba(102,51,153,.28);
          border-left: 5px solid ${colors[kind]}; animation: in .22s ease-out; }
        @keyframes in { from { opacity: 0; transform: translateY(10px); } }
        @media (prefers-reduced-motion: reduce) { .card { animation: none; } }
        .top { display: flex; gap: 10px; align-items: flex-start; padding: 12px 12px 10px 14px; }
        .ico { flex: none; width: 24px; height: 24px; border-radius: 50%; display: grid; place-items: center;
          background: ${colors[kind]}; color: #fff; font-weight: 700; font-size: 13px; }
        .txt { flex: 1; }
        b { display: block; font-size: 14.5px; color: #7c067e; }
        p { margin: 2px 0 0; color: #4a5a68; }
        .chips { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px; }
        .chip { background: #fefbd5; color: #6b4a00; border: 1px solid #f2c65d; border-radius: 999px; padding: 1px 8px; font-size: 12px; font-weight: 600; }
        .x { border: 0; background: none; font-size: 18px; line-height: 1; color: #a8a29e; cursor: pointer; padding: 2px 4px; border-radius: 6px; }
        .x:hover { background: #f5f5f4; color: #1c1917; }
        .foot { background: #663399; padding: 7px 14px; font-size: 12px; color: #fff; }
        .bar { height: 3px; background: #f2c65d; animation: shrink 10s linear forwards; }
        @keyframes shrink { from { width: 100%; } to { width: 0; } }
      </style>
      <div class="card" role="status">
        <div class="top">
          <span class="ico">${kind === 'ok' ? '✓' : kind === 'warn' ? '!' : '✕'}</span>
          <div class="txt"><b></b><p class="d"></p><div class="chips"></div></div>
          <button class="x" aria-label="Close">×</button>
        </div>
        <div class="foot">TTD Smart Fill · you enter the CAPTCHA/OTP and submit</div>
        <div class="bar"></div>
      </div>`;
    root.querySelector('b').textContent = title;
    root.querySelector('.d').textContent = detail;
    const chips = root.querySelector('.chips');
    missed.forEach((k) => {
      const c = document.createElement('span');
      c.className = 'chip';
      c.textContent = LABELS[k] || k;
      chips.appendChild(c);
    });
    if (!missed.length) chips.remove();
    root.querySelector('.x').addEventListener('click', () => host.remove());
    document.body.appendChild(host);

    // Auto-dismiss after 10s; hovering pauses it, leaving restarts a shorter 4s countdown.
    const bar = root.querySelector('.bar');
    let timer = setTimeout(() => host.remove(), 10000);
    host.addEventListener('mouseenter', () => { clearTimeout(timer); bar.style.animationPlayState = 'paused'; });
    host.addEventListener('mouseleave', () => {
      bar.style.animation = 'none';
      void bar.offsetWidth; // restart the animation
      bar.style.animation = 'shrink 4s linear forwards';
      timer = setTimeout(() => host.remove(), 4000);
    });
  }

  function waitForForm(timeout = 10000) {
    const ready = () => findControls('fullName').length > 0 || findControls('age').length > 0;
    if (ready()) return Promise.resolve(true);
    return new Promise((resolve) => {
      const obs = new MutationObserver(() => { if (ready()) { obs.disconnect(); resolve(true); } });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(ready()); }, timeout);
    });
  }

  // Wait briefly for a control that is disabled until another field is chosen.
  async function waitUntilUsable(el) {
    const usable = () => !el.disabled && el.getAttribute('aria-disabled') !== 'true';
    if (!usable()) await waitFor(usable, 1000);
    return usable() && !el.readOnly;
  }

  async function fillOne(el, key, value) {
    if (isForbidden(el)) return false;
    if (!(await waitUntilUsable(el))) return false;
    const tag = el.tagName.toLowerCase();
    if (tag === 'select') return fillSelect(el, key, value);
    if (tag === 'input' || tag === 'textarea') {
      const isAuto = el.getAttribute('aria-autocomplete') === 'list' || el.hasAttribute('matautocomplete');
      if (isAuto) return fillAutocomplete(el, key, value);
      el.focus();
      setNativeValue(el, value);
      return true;
    }
    return fillCustomDropdown(el, key, value);
  }

  async function fill(pilgrims, opts = {}) {
    if (!(await waitForForm())) {
      const message = 'No pilgrim form found on this page. Open the pilgrim-details step first.';
      toast({ kind: 'err', title: 'Pilgrim form not found', detail: 'Go to the pilgrim-details step, then click Fill again.' });
      return { ok: false, filled: 0, missed: [], skipped: 0, message };
    }

    // Only fill as many pilgrims as the form has rows; report the rest.
    const rows = findControls('fullName').length || findControls('age').length;
    const list = pilgrims.slice(0, rows);
    const skipped = pilgrims.length - list.length;

    let filled = 0;
    const missed = new Set();
    const mark = (el) => { filled++; if (opts.highlight) highlight(el); };

    for (const key of Object.keys(MAP)) {
      if (!list.some((p) => p[key])) continue;
      let controls = findControls(key);
      if (DEPENDENT.has(key) && controls.length < list.length) {
        controls = (await waitFor(() => { const c = findControls(key); return c.length >= list.length ? c : null; }, 1000)) || findControls(key);
      }
      const radios = !controls.length && key === 'gender' ? radioGroups(key) : [];

      for (let row = 0; row < list.length; row++) {
        const value = list[row][key];
        if (value == null || value === '') continue;

        if (radios.length) {
          const host = radios[row] && fillRadio(radios[row], key, value);
          if (host) mark(host); else if (row === 0) missed.add(key);
          continue;
        }
        const el = controls[row];
        // Contact fields often appear once per booking; extra pilgrims simply have no slot.
        if (!el) { if (row === 0) missed.add(key); continue; }
        try {
          if (await fillOne(el, key, value)) mark(el); else missed.add(key);
        } catch (e) {
          missed.add(key);
          console.warn('[TTD Smart Fill]', key, e);
        }
        await sleep(80);
      }
    }

    const missedList = [...missed];
    const skippedNote = skipped
      ? ` The form has ${rows} pilgrim row${rows === 1 ? '' : 's'}, so ${skipped} pilgrim${skipped === 1 ? ' was' : 's were'} not filled.`
      : '';
    const message = `Filled ${filled} field${filled === 1 ? '' : 's'}.` +
      (missedList.length ? ` Not matched: ${missedList.map((k) => LABELS[k]).join(', ')}.` : '') +
      skippedNote + ' Please verify, then enter CAPTCHA/OTP and submit yourself.';
    toast(filled === 0
      ? { kind: 'err', title: 'Nothing was filled', detail: 'The fields on this page could not be matched.', missed: missedList }
      : missedList.length || skipped
        ? { kind: 'warn', title: `Filled ${filled} fields`, detail: (missedList.length ? 'Fill these by hand, then check everything:' : 'Please check every field.') + skippedNote, missed: missedList }
        : { kind: 'ok', title: `Filled ${filled} fields`, detail: 'Please check every field before you continue.' });
    return { ok: filled > 0, filled, missed: missedList, skipped, rows, message };
  }

  // Lists the controls the extension can see, to help update fieldMap selectors.
  function scan() {
    return [...document.querySelectorAll(CONTROL_SEL)].filter(isVisible).map((el) => ({
      tag: el.tagName.toLowerCase(),
      type: el.type || '',
      attrs: attrText(el),
      label: labelText(el),
      forbidden: isForbidden(el),
    }));
  }

  const onMessage = (msg, _sender, sendResponse) => {
    if (!msg) return false;
    if (msg.type === 'FILL') {
      fill(msg.pilgrims || [], { highlight: msg.highlight !== false })
        .then(sendResponse)
        .catch((e) => sendResponse({ ok: false, filled: 0, missed: [], skipped: 0, message: String((e && e.message) || e) }));
      return true;
    }
    if (msg.type === 'SCAN') { sendResponse({ ok: true, fields: scan() }); return false; }
    if (msg.type === 'PING') { sendResponse({ ok: true }); return false; }
    return false;
  };
  chrome.runtime.onMessage.addListener(onMessage);

  window.__ttdSmartFill = {
    alive: () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch { return false; } },
    dispose: () => { try { chrome.runtime.onMessage.removeListener(onMessage); } catch { /* orphaned */ } },
  };
})();
