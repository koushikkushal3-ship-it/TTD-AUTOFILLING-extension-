// Field matching rules for TTD pilgrim forms.
// `selectors` are tried first (exact DOM hooks captured from the live site).
// `attr` is tested against EACH of name / formcontrolname / id / placeholder / aria-label,
//   after splitting it into lowercase words ("idProofNumber" -> "id proof number").
// `label` is tested against the visible label text near the control (lowercase).
// `exclude` rejects a control if any attribute or its label matches.
// Keys are filled in this order, so parents come before dependants
// (ID type before ID number, state before city).
// Fill in `selectors` after inspecting the logged-in pilgrim-details page
// (open the popup and use "Scan fields" to list what the extension sees).
window.TTD_FIELD_MAP = {
  fullName: {
    selectors: [],
    attr: /\bname\b/,
    label: /^(pilgrim\s*)?(full\s*)?name\b|name\s*\(as per/,
    exclude: /\b(user|login|father|guardian|nominee|state|city|district|bank|holder|file)\b/,
  },
  age: { selectors: [], attr: /\bage\b/, label: /^age\b/ },
  gender: { selectors: [], attr: /\b(gender|sex)\b/, label: /^(gender|sex)\b/ },
  idProofType: {
    selectors: [],
    attr: /\b(id|photo id|proof|id proof|photo id proof|document|identity)( proof)? type\b|^(photo )?id proof$/,
    label: /(photo\s*)?id\s*(proof)?\s*type|^(photo\s*)?id\s*proof$|document\s*type/,
  },
  idNumber: {
    selectors: [],
    attr: /\b(id|proof|document|identity|aadhaa?r|card)( proof)? (no|num|number)\b|^aadhaa?r$/,
    label: /(id|proof|document)\s*(proof\s*)?(no|number)|aadhaa?r/,
  },
  mobile: { selectors: [], attr: /\b(mobile|phone|cell)\b|\bcontact (no|num|number)\b|^contact$/, label: /mobile|phone|contact\s*no/ },
  email: { selectors: [], attr: /\be ?mail\b/, label: /e-?mail/ },
  state: { selectors: [], attr: /\bstate\b/, label: /^state\b/ },
  city: { selectors: [], attr: /\b(city|town)\b/, label: /^(city|town)\b/ },
  pincode: { selectors: [], attr: /\b(pin ?code|zip|postal( code)?)\b/, label: /pin\s*code|zip|postal/ },
};

// Never type into or click controls matching this (substring match, so "mobileOtp" is caught too).
window.TTD_FORBIDDEN = /captcha|otp|one\s*time|password|submit|pay|proceed|confirm|verify/i;

// Aliases so saved values match the option text shown on TTD dropdowns.
window.TTD_VALUE_ALIASES = {
  gender: {
    male: ['male', 'm'],
    female: ['female', 'f'],
    other: ['other', 'others', 'transgender', 'third gender', 'o'],
  },
  idProofType: {
    aadhaar: ['aadhaar', 'aadhar', 'aadhaar card', 'aadhar card', 'uid'],
    passport: ['passport'],
    pan: ['pan', 'pan card'],
    voter: ['voter id', 'voter', 'voter id card', 'epic', 'election card'],
    driving: ['driving licence', 'driving license', 'driving', 'dl'],
    ration: ['ration card', 'ration'],
  },
};
