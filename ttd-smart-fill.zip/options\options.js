const $ = (id) => document.getElementById(id);
const AVATAR_COLORS = ['#663399', '#7c067e', '#0c5273', '#8e4bb5', '#a10007', '#4a2d8a', '#9c5a00'];
const CONTACT_FIELDS = ['mobile', 'email', 'city', 'state', 'pincode'];
const DIGIT_FIELDS = { mobile: 10, pincode: 6, age: 3 };

// Stored form of an ID number: no spaces, upper case, and no dashes except in
// driving licences (where they are part of the number).
const normalizeId = (type, v) => {
  const s = v.replace(/\s/g, '').toUpperCase();
  return type === 'Driving Licence' ? s : s.replace(/-/g, '');
};

const ID_RULES = {
  Aadhaar: { re: /^\d{12}$/, hint: '12 digits, e.g. 1234 5678 9012', max: 14, ph: '1234 5678 9012' },
  Passport: { re: /^[A-Z][0-9]{7}$/, hint: '1 letter + 7 digits, e.g. K1234567', max: 8, ph: 'K1234567' },
  PAN: { re: /^[A-Z]{5}[0-9]{4}[A-Z]$/, hint: '10 characters, e.g. ABCDE1234F', max: 10, ph: 'ABCDE1234F' },
  'Voter ID': { re: /^[A-Z]{3}[0-9]{7}$/, hint: '3 letters + 7 digits, e.g. ABC1234567', max: 10, ph: 'ABC1234567' },
  'Driving Licence': { re: /^[A-Z0-9-]{10,20}$/, hint: '10–20 letters or digits', max: 20, ph: 'AP0120190001234' },
  'Ration Card': { re: /^[A-Z0-9]{6,20}$/, hint: '6–20 letters or digits', max: 20, ph: '' },
};

let state = { profiles: [], activeProfileId: null, settings: {} };
let editingId = null; // id of the profile open in the editor (null = new, unsaved)
let editorOpen = false;
let dirty = false;
let snapshot = null; // last saved/loaded version, for Discard

/* ---------- helpers ---------- */

const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  kids.forEach((k) => k != null && n.append(k));
  return n;
};

function initials(name) {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

function colorFor(name, i) {
  let h = 0;
  for (const c of name || String(i)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

function avatar(name, i) {
  const a = el('span', { className: 'av', textContent: initials(name) || String(i + 1) });
  a.style.background = colorFor(name, i);
  return a;
}

function toast(text, { kind = 'ok', action, onAction } = {}) {
  const t = el('div', { className: 'toast ' + kind },
    el('span', { className: 't-ico', textContent: kind === 'ok' ? '✓' : '!' }),
    el('span', { textContent: text }));
  if (action) {
    const b = el('button', { className: 'undo', type: 'button', textContent: action });
    b.addEventListener('click', () => { t.remove(); onAction(); });
    t.append(b);
  }
  $('toasts').append(t);
  setTimeout(() => t.remove(), action ? 7000 : 3200);
}

// Resolves true on OK. With `alt`, resolves 'ok' | 'alt' | 'cancel' instead.
function confirmDialog({ title, text, ok = 'Delete', danger = true, alt }) {
  const d = $('confirm');
  $('confirmTitle').textContent = title;
  $('confirmText').textContent = text;
  $('confirmOk').textContent = ok;
  $('confirmOk').classList.toggle('danger-fill', danger);
  $('confirmAlt').hidden = !alt;
  $('confirmAlt').textContent = alt || '';
  d.returnValue = 'cancel';
  d.showModal();
  // Resolve straight from the button's submit event; the dialog's `close` event is
  // queued and can be held back (e.g. in a background page), so it is only a
  // fallback for Escape.
  const form = d.querySelector('form');
  return new Promise((resolve) => {
    const finish = (value) => {
      form.removeEventListener('submit', onSubmit);
      d.removeEventListener('close', onClose);
      resolve(alt ? value : value === 'ok');
    };
    const onSubmit = (e) => finish((e.submitter && e.submitter.value) || 'cancel');
    const onClose = () => finish(d.returnValue || 'cancel');
    form.addEventListener('submit', onSubmit);
    d.addEventListener('close', onClose);
  });
}

// Keep the URL hash pointing at the open profile, so reloading reopens it.
function setHash(h) {
  try { history.replaceState(null, '', h ? '#' + h : location.pathname); } catch { /* not allowed in sandboxed previews */ }
}

/* ---------- sidebar ---------- */

function renderList() {
  const q = $('search').value.trim().toLowerCase();
  const ul = $('profileList');
  ul.replaceChildren();
  let shown = 0;
  state.profiles.forEach((p) => {
    const hay = (p.name + ' ' + p.pilgrims.map((x) => x.fullName).join(' ')).toLowerCase();
    if (q && !hay.includes(q)) return;
    shown++;
    const stack = el('span', { className: 'stack' });
    p.pilgrims.slice(0, 3).forEach((pg, i) => stack.append(avatar(pg.fullName, i)));
    const names = p.pilgrims.map((x) => x.fullName.split(' ')[0]).filter(Boolean).join(', ');
    const isEditing = editorOpen && p.id === editingId;
    const btn = el('button', { className: 'pitem', type: 'button' },
      el('span', { className: 'meta' },
        el('span', { className: 'name' },
          el('span', { textContent: p.name }),
          p.id === state.activeProfileId ? el('b', { className: 'star', textContent: '★', title: 'Default in popup' }) : null),
        el('span', { className: 'sub', textContent: `${p.pilgrims.length} pilgrim${p.pilgrims.length === 1 ? '' : 's'}${names ? ' · ' + names : ''}` })),
      isEditing && dirty ? el('span', { className: 'dirty', title: 'Unsaved changes' }) : null,
      stack);
    btn.setAttribute('aria-current', String(isEditing));
    btn.addEventListener('click', () => requestOpen(p));
    ul.append(el('li', {}, btn));
  });
  $('noMatch').hidden = shown > 0 || !state.profiles.length;
}

/* ---------- editor: pilgrim cards ---------- */

function cards() { return [...$('pilgrims').children]; }

function fieldValue(card, f) {
  if (f === 'gender') {
    const r = card.querySelector('[data-f="gender"] input:checked');
    return r ? r.value : '';
  }
  const input = card.querySelector(`[data-f="${f}"]`);
  return input ? input.value.trim() : '';
}

function setFieldValue(card, f, v) {
  if (f === 'gender') {
    card.querySelectorAll('[data-f="gender"] input').forEach((r) => { r.checked = r.value.toLowerCase() === String(v || '').toLowerCase(); });
    return;
  }
  const input = card.querySelector(`[data-f="${f}"]`);
  if (input) input.value = v || '';
}

function updateIdHint(card) {
  const type = fieldValue(card, 'idProofType');
  const rule = ID_RULES[type];
  const input = card.querySelector('[data-f="idNumber"]');
  card.querySelector('.hint').textContent = rule ? rule.hint : 'Choose the ID type first';
  input.placeholder = rule ? rule.ph : '';
  input.maxLength = rule ? rule.max : 30;
}

function updateCardHeader(card) {
  const i = cards().indexOf(card);
  const name = fieldValue(card, 'fullName');
  const av = card.querySelector('.av');
  av.textContent = initials(name) || String(i + 1);
  av.style.background = colorFor(name, i);
  card.querySelector('.pname').textContent = name || `Pilgrim ${i + 1}`;
  const age = fieldValue(card, 'age');
  const idNo = fieldValue(card, 'idNumber').replace(/\s/g, '');
  const bits = [age && `${age} yrs`, fieldValue(card, 'gender'), fieldValue(card, 'idProofType') && `${fieldValue(card, 'idProofType')}${idNo ? ' •••• ' + idNo.slice(-4) : ''}`].filter(Boolean);
  card.querySelector('.psum').textContent = bits.join(' · ') || 'Not filled yet';
}

function setCollapsed(card, collapsed) {
  card.classList.toggle('collapsed', collapsed);
  card.querySelector('.collapse').setAttribute('aria-expanded', String(!collapsed));
}

function addPilgrimCard(data, { collapsed = false, focus = false } = {}) {
  if (cards().length >= TTDStore.MAX_PILGRIMS) return null;
  const card = $('pilgrimTpl').content.firstElementChild.cloneNode(true);
  const group = 'g-' + TTDStore.uid();
  card.querySelectorAll('[data-f="gender"] input').forEach((r) => { r.name = group; });
  TTDStore.PILGRIM_FIELDS.forEach((f) => setFieldValue(card, f, data && data[f]));

  card.querySelector('.collapse').addEventListener('click', () => setCollapsed(card, !card.classList.contains('collapsed')));
  card.querySelector('.remove').addEventListener('click', () => removePilgrim(card));
  card.querySelector('[data-f="idProofType"]').addEventListener('change', () => { updateIdHint(card); validateCard(card, true); });
  card.addEventListener('input', () => { updateCardHeader(card); markDirty(); });
  card.addEventListener('change', () => { updateCardHeader(card); markDirty(); });
  // Validate a field once the user leaves it.
  card.addEventListener('focusout', (e) => {
    const f = e.target.closest('[data-f]') || e.target.closest('.seg');
    if (f) { e.target.dataset.touched = '1'; validateCard(card, true); }
  });
  // Keep numeric fields numeric as the user types or pastes. These inputs have no
  // maxlength on purpose: the browser would cut a pasted "+91 98765 43210" to
  // "+91 98765 " before this cleanup could strip the prefix and spaces.
  Object.entries(DIGIT_FIELDS).forEach(([f, max]) => {
    const input = card.querySelector(`[data-f="${f}"]`);
    input.addEventListener('input', () => {
      let v = input.value.replace(/\D/g, '');
      if (f === 'mobile' && v.length > 10) v = v.replace(/^(91|0)/, '');
      v = v.slice(0, max);
      if (v !== input.value) input.value = v;
    });
  });

  $('pilgrims').append(card);
  updateIdHint(card);
  setCollapsed(card, collapsed);
  renumber();
  if (focus) card.querySelector('[data-f="fullName"]').focus();
  return card;
}

async function removePilgrim(card) {
  const name = fieldValue(card, 'fullName');
  const hasData = TTDStore.PILGRIM_FIELDS.some((f) => fieldValue(card, f));
  if (hasData && !(await confirmDialog({ title: `Remove ${name || 'this pilgrim'}?`, text: 'Their details will be removed from this profile when you save.', ok: 'Remove' }))) return;
  const list = cards();
  // Contact details live on the first pilgrim; hand them to the next one.
  if (list[0] === card && list[1]) {
    CONTACT_FIELDS.forEach((f) => { if (!fieldValue(list[1], f)) setFieldValue(list[1], f, fieldValue(card, f)); });
  }
  card.remove();
  if (!cards().length) addPilgrimCard(null, { focus: true });
  renumber();
  markDirty();
}

function renumber() {
  const list = cards();
  list.forEach((card, i) => {
    card.querySelector('.contact').hidden = i !== 0;
    card.querySelector('.remove').hidden = list.length === 1;
    updateCardHeader(card);
  });
  const max = TTDStore.MAX_PILGRIMS;
  $('addPilgrim').disabled = list.length >= max;
  $('addPilgrim').querySelector('span').textContent = list.length >= max ? 'Maximum reached' : 'Add pilgrim';
  $('pilgrimCount').textContent = `${list.length} / ${max}`;
}

/* ---------- validation ---------- */

function fieldError(card, f, isFirst) {
  const v = fieldValue(card, f);
  const required = ['fullName', 'age', 'gender', 'idProofType', 'idNumber'];
  if (required.includes(f) && !v) return 'Required';
  if (!v) return '';
  if (f === 'fullName' && !/^[\p{L}\p{M} .'-]{2,}$/u.test(v)) return 'Use letters only, as printed on the ID';
  if (f === 'age' && !(Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 120)) return 'Enter an age from 1 to 120';
  if (f === 'idNumber') {
    const rule = ID_RULES[fieldValue(card, 'idProofType')];
    if (rule && !rule.re.test(normalizeId(fieldValue(card, 'idProofType'), v))) return rule.hint;
  }
  if (!isFirst) return '';
  if (f === 'mobile' && !/^[6-9]\d{9}$/.test(v)) return 'Enter a valid 10-digit mobile number';
  if (f === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'Enter a valid email address';
  if (f === 'pincode' && !/^[1-9]\d{5}$/.test(v)) return 'PIN code is 6 digits';
  return '';
}

// onlyTouched: during typing, only show errors for fields the user has left.
function validateCard(card, onlyTouched = false) {
  const isFirst = cards()[0] === card;
  let bad = 0;
  TTDStore.PILGRIM_FIELDS.forEach((f) => {
    const input = card.querySelector(`[data-f="${f}"]`);
    const box = input.closest('.field');
    const touched = f === 'gender' ? [...input.querySelectorAll('input')].some((r) => r.dataset.touched) : input.dataset.touched;
    const err = fieldError(card, f, isFirst);
    if (err) bad++;
    const show = err && (!onlyTouched || touched);
    input.classList.toggle('invalid', !!show);
    box.querySelector('.err-text').textContent = show ? err : '';
  });
  card.classList.toggle('has-error', !onlyTouched && bad > 0);
  return bad;
}

/* ---------- editor lifecycle ---------- */

function markDirty() {
  if (!editorOpen) return;
  const was = dirty;
  dirty = JSON.stringify(collect()) !== JSON.stringify(snapshot);
  $('savebar').classList.toggle('dirty', dirty);
  $('saveState').querySelector('.txt').textContent = dirty ? 'Unsaved changes' : (editingId ? 'All changes saved' : 'New profile, not saved yet');
  if (was !== dirty) renderList();
}

function collect() {
  return {
    id: editingId,
    name: $('profileName').value.trim(),
    pilgrims: cards().map((card, i) => {
      const p = TTDStore.emptyPilgrim();
      TTDStore.PILGRIM_FIELDS.forEach((f) => {
        if (i > 0 && CONTACT_FIELDS.includes(f)) return;
        let v = fieldValue(card, f);
        if (f === 'idNumber') v = normalizeId(fieldValue(card, 'idProofType'), v);
        p[f] = v;
      });
      return p;
    }),
  };
}

function openEditor(profile) {
  editorOpen = true;
  editingId = profile ? profile.id : null;
  $('welcome').hidden = true;
  $('editor').hidden = false;
  $('profileName').value = profile ? profile.name : '';
  $('profileName').classList.remove('invalid');
  document.querySelector('[data-err-for="profileName"]').textContent = '';
  $('pilgrims').replaceChildren();
  const list = profile && profile.pilgrims.length ? profile.pilgrims : [null];
  list.forEach((p, i) => addPilgrimCard(p, { collapsed: list.length > 2 && i > 0 }));
  $('delete').hidden = !profile;
  $('duplicate').hidden = !profile;
  renderDefaultChip();
  snapshot = collect();
  dirty = false;
  markDirty();
  renderList();
  setHash(profile ? encodeURIComponent(profile.id) : 'new');
  if (!profile) $('profileName').focus();
  window.scrollTo({ top: 0 });
}

function closeEditor() {
  editorOpen = false;
  editingId = null;
  dirty = false;
  $('editor').hidden = true;
  $('welcome').hidden = false;
  $('welcomeTitle').textContent = state.profiles.length ? 'Pick a profile to edit' : 'Save pilgrim details once, fill them in seconds';
  setHash('');
  renderList();
}

async function requestOpen(profile) {
  if (editorOpen && profile && profile.id === editingId) return;
  if (dirty && !(await confirmDialog({ title: 'Discard unsaved changes?', text: 'Your edits to this profile have not been saved.', ok: 'Discard' }))) return;
  openEditor(profile);
}

function renderDefaultChip() {
  const chip = $('makeDefault');
  const isDefault = !!editingId && editingId === state.activeProfileId;
  chip.hidden = !editingId;
  chip.classList.toggle('is-default', isDefault);
  chip.textContent = isDefault ? '★ Default in popup' : '☆ Set as default';
  chip.disabled = isDefault;
}

async function save() {
  const data = collect();
  const nameErr = data.name ? '' : 'Give this profile a name, e.g. "Family"';
  $('profileName').classList.toggle('invalid', !!nameErr);
  document.querySelector('[data-err-for="profileName"]').textContent = nameErr;

  let firstBad = null;
  cards().forEach((card) => {
    if (validateCard(card) && !firstBad) firstBad = card;
  });
  if (nameErr) { $('profileName').focus(); toast('Please fix the highlighted fields', { kind: 'err' }); return; }
  if (firstBad) {
    setCollapsed(firstBad, false);
    const input = firstBad.querySelector('.invalid');
    firstBad.scrollIntoView({ behavior: 'smooth', block: 'center' });
    if (input) (input.matches('.seg') ? input.querySelector('input') : input).focus({ preventScroll: true });
    toast('Please fix the highlighted fields', { kind: 'err' });
    return;
  }

  const saved = await TTDStore.saveProfile({ ...data, id: editingId || TTDStore.uid() });
  state = await TTDStore.getAll();
  editingId = saved.id;
  snapshot = collect();
  $('delete').hidden = false;
  $('duplicate').hidden = false;
  setHash(encodeURIComponent(saved.id));
  renderDefaultChip();
  markDirty();
  renderList();
  toast('Profile saved');
}

/* ---------- events ---------- */

$('editor').addEventListener('submit', (e) => { e.preventDefault(); save(); });
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && editorOpen) { e.preventDefault(); save(); }
});
$('profileName').addEventListener('input', () => {
  if ($('profileName').value.trim()) { $('profileName').classList.remove('invalid'); document.querySelector('[data-err-for="profileName"]').textContent = ''; }
  markDirty();
});

$('newProfile').addEventListener('click', () => requestOpen(null));
$('welcomeNew').addEventListener('click', () => requestOpen(null));
$('addPilgrim').addEventListener('click', () => {
  cards().forEach((c) => setCollapsed(c, true));
  const card = addPilgrimCard(null, { focus: true });
  if (card) card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  markDirty();
});

$('discard').addEventListener('click', () => {
  const p = state.profiles.find((x) => x.id === editingId);
  if (p) openEditor(p); else closeEditor();
  toast('Changes discarded');
});

$('makeDefault').addEventListener('click', async () => {
  if (!editingId) return;
  await TTDStore.setActive(editingId);
  state.activeProfileId = editingId;
  renderDefaultChip();
  renderList();
  toast('Set as default in the popup');
});

$('delete').addEventListener('click', async () => {
  const p = state.profiles.find((x) => x.id === editingId);
  if (!p) return;
  if (!(await confirmDialog({ title: `Delete "${p.name}"?`, text: `This removes ${p.pilgrims.length} pilgrim${p.pilgrims.length === 1 ? '' : 's'} from this device.` }))) return;
  const wasDefault = state.activeProfileId === p.id;
  await TTDStore.deleteProfile(p.id);
  state = await TTDStore.getAll();
  closeEditor();
  toast(`Deleted "${p.name}"`, {
    action: 'Undo',
    onAction: async () => {
      await TTDStore.saveProfile(p);
      if (wasDefault) await TTDStore.setActive(p.id);
      state = await TTDStore.getAll();
      renderList();
      // The user may have started editing another profile since; don't drop those edits.
      requestOpen(state.profiles.find((x) => x.id === p.id));
    },
  });
});

$('duplicate').addEventListener('click', async () => {
  const src = state.profiles.find((x) => x.id === editingId);
  if (!src) return;
  if (dirty && !(await confirmDialog({ title: 'Discard unsaved changes?', text: 'The copy is made from the last saved version.', ok: 'Continue', danger: false }))) return;
  const copy = await TTDStore.saveProfile({ ...src, id: TTDStore.uid(), name: src.name + ' (copy)' });
  state = await TTDStore.getAll();
  openEditor(copy);
  toast('Copy created');
});

$('export').addEventListener('click', async () => {
  if (!state.profiles.length) { toast('Nothing to export yet', { kind: 'err' }); return; }
  const json = await TTDStore.exportJSON();
  const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  const a = el('a', { href: url, download: `ttd-smart-fill-backup-${new Date().toISOString().slice(0, 10)}.json` });
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast(`Exported ${state.profiles.length} profile${state.profiles.length === 1 ? '' : 's'}${dirty ? ' (unsaved changes not included)' : ''}`);
});

$('importBtn').addEventListener('click', () => $('import').click());
$('import').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  if (dirty && !(await confirmDialog({ title: 'Discard unsaved changes?', text: 'Importing reloads your profiles, so unsaved edits to this profile will be lost.', ok: 'Discard' }))) return;
  try {
    const text = await file.text();
    let mode = 'merge';
    if (state.profiles.length) {
      const choice = await confirmDialog({
        title: `Import "${file.name}"`,
        text: 'Merge keeps your current profiles and adds or updates the ones in the file. Replace all deletes current profiles first.',
        ok: 'Replace all',
        alt: 'Merge',
      });
      if (choice === 'cancel') return;
      mode = choice === 'ok' ? 'replace' : 'merge';
    }
    const n = await TTDStore.importJSON(text, mode);
    state = await TTDStore.getAll();
    closeEditor();
    toast(`Imported ${n} profile${n === 1 ? '' : 's'}`);
  } catch (err) {
    toast('Import failed: ' + err.message, { kind: 'err' });
  }
});

$('highlight').addEventListener('change', async (e) => {
  state.settings = { ...state.settings, highlightFilled: e.target.checked };
  await chrome.storage.local.set({ settings: state.settings });
  toast(e.target.checked ? 'Filled fields will be highlighted' : 'Highlighting turned off');
});

$('search').addEventListener('input', renderList);

window.addEventListener('beforeunload', (e) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

// Keep the sidebar in sync if the popup changes the default profile.
chrome.storage.onChanged.addListener(async (_c, area) => {
  if (area !== 'local') return;
  state = await TTDStore.getAll();
  renderList();
  renderDefaultChip();
});

/* ---------- init ---------- */

(async function init() {
  state = await TTDStore.getAll();
  $('highlight').checked = state.settings.highlightFilled !== false;
  const hash = decodeURIComponent(location.hash.slice(1));
  const target = state.profiles.find((p) => p.id === hash);
  if (target) openEditor(target);
  else if (hash === 'new') openEditor(null);
  else closeEditor();
})();
