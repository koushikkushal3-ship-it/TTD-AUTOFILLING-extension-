const TTD_HOST = 'ttdevasthanams.ap.gov.in';
const TTD_URL = 'https://ttdevasthanams.ap.gov.in/';
const REQUIRED = ['fullName', 'age', 'gender', 'idProofType', 'idNumber'];
const FIELD_LABELS = {
  fullName: 'Name', age: 'Age', gender: 'Gender', idProofType: 'ID type', idNumber: 'ID number',
  mobile: 'Mobile', email: 'Email', city: 'City', state: 'State', pincode: 'PIN code',
};
const AVATAR_COLORS = ['#663399', '#7c067e', '#0c5273', '#8e4bb5', '#a10007', '#4a2d8a', '#9c5a00'];
const $ = (id) => document.getElementById(id);

let state = { profiles: [], activeProfileId: null, settings: {} };
let tab = null;
let onTtd = false;

const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  kids.forEach((k) => k != null && n.append(k));
  return n;
};

function initials(name) {
  const parts = (name || '?').trim().split(/\s+/);
  return ((parts[0] || '?')[0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

function avatar(name, i) {
  const a = el('span', { className: 'av', textContent: initials(name) });
  let h = 0;
  for (const c of name || String(i)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  a.style.background = AVATAR_COLORS[h % AVATAR_COLORS.length];
  return a;
}

const maskId = (v) => (v ? '•••• ' + String(v).slice(-4) : '');
const activeProfile = () => state.profiles.find((p) => p.id === state.activeProfileId);

async function getTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}

function isTtd(t) {
  try { return new URL(t.url).hostname === TTD_HOST; } catch { return false; }
}

// Message the content script, injecting it first if the tab was open before install.
async function sendToTab(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content/fieldMap.js', 'content/content.js'] });
    return chrome.tabs.sendMessage(tabId, msg);
  }
}

function showResult(kind, title, detail) {
  const r = $('result');
  const icons = { ok: '✓', warn: '!', err: '✕' };
  r.className = 'result ' + kind;
  r.replaceChildren(el('span', { className: 'ico', textContent: icons[kind] }), el('b', { textContent: title }), detail ? el('p', { textContent: detail }) : '');
  r.hidden = false;
}

function renderProfiles() {
  const box = $('profiles');
  box.replaceChildren();
  $('profileCount').textContent = `${state.profiles.length} saved`;
  state.profiles.forEach((p) => {
    const checked = p.id === state.activeProfileId;
    const stack = el('span', { className: 'stack' });
    p.pilgrims.slice(0, 3).forEach((pg, i) => stack.append(avatar(pg.fullName, i)));
    const btn = el('button', { className: 'profile', type: 'button', tabIndex: checked ? 0 : -1 },
      el('span', { className: 'radio' }),
      el('span', { className: 'meta' },
        el('span', { className: 'name', textContent: p.name }),
        el('span', { className: 'sub', textContent: `${p.pilgrims.length} pilgrim${p.pilgrims.length === 1 ? '' : 's'}` })),
      stack);
    btn.setAttribute('role', 'radio');
    btn.setAttribute('aria-checked', String(checked));
    btn.dataset.id = p.id;
    btn.addEventListener('click', () => selectProfile(p.id));
    box.append(btn);
  });
}

function renderPilgrims() {
  const list = $('pilgrimList');
  list.replaceChildren();
  const profile = activeProfile();
  if (!profile || !profile.pilgrims.length) {
    list.append(el('li', { className: 'none', textContent: 'No pilgrims in this profile yet.' }));
    return;
  }
  profile.pilgrims.forEach((p, i) => {
    const missing = REQUIRED.filter((f) => !p[f]);
    const bits = [p.age && `${p.age} yrs`, p.gender].filter(Boolean).join(' · ');
    list.append(el('li', {},
      avatar(p.fullName, i),
      el('span', { className: 'who' },
        el('b', { textContent: p.fullName || `Pilgrim ${i + 1}` }),
        el('span', { textContent: bits || '—' })),
      missing.length
        ? el('span', { className: 'warn-chip', textContent: `${missing.length} missing`, title: 'Missing: ' + missing.map((k) => FIELD_LABELS[k]).join(', ') })
        : el('span', { className: 'id', textContent: `${p.idProofType || ''}\n${maskId(p.idNumber)}` })));
  });
}

function renderFillButton() {
  const btn = $('fill');
  const label = btn.querySelector('.btn-label');
  const profile = activeProfile();
  if (!onTtd) {
    label.textContent = 'Open TTD website';
    btn.disabled = false;
  } else {
    label.textContent = profile ? `Fill ${profile.pilgrims.length} pilgrim${profile.pilgrims.length === 1 ? '' : 's'}` : 'Fill TTD form';
    btn.disabled = !profile || !profile.pilgrims.length;
  }
}

async function selectProfile(id) {
  state.activeProfileId = id;
  await TTDStore.setActive(id);
  renderProfiles();
  renderPilgrims();
  renderFillButton();
  $('result').hidden = true;
  const cur = document.querySelector(`.profile[data-id="${CSS.escape(id)}"]`);
  if (cur) cur.focus();
}

async function render() {
  state = await TTDStore.getAll();
  tab = await getTab();
  onTtd = !!tab && isTtd(tab);

  $('sitePill').classList.toggle('on', onTtd);
  $('sitePill').classList.toggle('off', !onTtd);
  $('siteText').textContent = onTtd ? 'TTD page detected' : 'Not on the TTD website';

  const has = state.profiles.length > 0;
  $('empty').hidden = has;
  $('main').hidden = !has;
  $('scan').hidden = !onTtd;
  if (!has) return;

  if (!activeProfile()) state.activeProfileId = state.profiles[0].id;
  renderProfiles();
  renderPilgrims();
  renderFillButton();
}

// Arrow keys move between profile radios.
$('profiles').addEventListener('keydown', (e) => {
  if (!['ArrowDown', 'ArrowUp'].includes(e.key)) return;
  e.preventDefault();
  const ids = state.profiles.map((p) => p.id);
  const i = ids.indexOf(state.activeProfileId);
  const next = ids[(i + (e.key === 'ArrowDown' ? 1 : -1) + ids.length) % ids.length];
  selectProfile(next);
});

$('fill').addEventListener('click', async () => {
  if (!onTtd) { chrome.tabs.create({ url: TTD_URL }); window.close(); return; }
  const profile = activeProfile();
  if (!profile) return;
  const btn = $('fill');
  btn.disabled = true;
  btn.classList.add('loading');
  btn.querySelector('.btn-label').textContent = 'Filling…';
  $('result').hidden = true;
  try {
    const res = await sendToTab(tab.id, { type: 'FILL', pilgrims: profile.pilgrims, highlight: state.settings.highlightFilled !== false });
    const missed = (res && res.missed) || [];
    const skipped = (res && res.skipped) || 0;
    const skippedNote = skipped
      ? ` The form has only ${res.rows} pilgrim row${res.rows === 1 ? '' : 's'}; ${skipped} pilgrim${skipped === 1 ? ' was' : 's were'} not filled. Select more persons on TTD first.`
      : '';
    if (!res) showResult('err', 'No response from the page', 'Reload the TTD tab and try again.');
    else if (!res.ok && !res.filled && !missed.length) showResult('err', 'Form not found', 'Go to the pilgrim-details step, then click Fill again.');
    else if (!res.ok) showResult('err', 'Nothing was filled', `Couldn't match: ${missed.map((k) => FIELD_LABELS[k] || k).join(', ')}.`);
    else if (missed.length || skipped) {
      const matchNote = missed.length ? `Couldn't match: ${missed.map((k) => FIELD_LABELS[k] || k).join(', ')}. Fill those by hand.` : 'Check every field.';
      showResult('warn', `Filled ${res.filled} fields`, matchNote + skippedNote);
    } else showResult('ok', `Filled ${res.filled} fields`, 'Check every field, then enter the CAPTCHA/OTP and submit.');
  } catch (e) {
    showResult('err', "Couldn't reach the page", e.message);
  } finally {
    btn.classList.remove('loading');
    renderFillButton();
  }
});

$('scan').addEventListener('click', async () => {
  try {
    const res = await sendToTab(tab.id, { type: 'SCAN' });
    await navigator.clipboard.writeText(JSON.stringify(res.fields, null, 2));
    showResult('ok', `Copied ${res.fields.length} fields`, 'Paste this list to the developer to improve matching.');
  } catch (e) {
    showResult('err', 'Scan failed', e.message);
  }
});

const openOptions = (hash = '') => {
  chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html' + hash) });
  window.close();
};
$('manage').addEventListener('click', () => openOptions());
$('addFirst').addEventListener('click', () => openOptions('#new'));
$('editProfile').addEventListener('click', () => openOptions('#' + encodeURIComponent(state.activeProfileId || '')));

render();
